@extends('layouts.app')

@section('content')
<h1>Maestra de Órdenes de Compra</h1>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Producto</th>
            @foreach ($fechas as $fecha)
                <th>{{ $fecha }}</th>
            @endforeach
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($clientesConOrdenes as $clienteId => $productos)
            @php
                $cliente = App\Models\Cliente::find($clienteId);
            @endphp
            <tr>
                <td colspan="{{ $fechas->count() + 2 }}" class="bg-light">
                    {{ $cliente->nombre ?? 'Cliente Desconocido' }}
                </td>
            </tr>
            @foreach ($productos as $productoId => $ordenesPorFecha)
                @php
                    $producto = App\Models\Producto::find($productoId);
                @endphp
                <tr>
                    <td>{{ $producto->nombre ?? 'Producto Desconocido' }}</td>
                    @foreach ($fechas as $fecha)
                        <td>{{ $ordenesPorFecha->get($fecha, collect())->sum('unidades') }}</td>
                    @endforeach
                    <td>{{ $ordenesPorFecha->flatten()->sum('unidades') }}</td>
                </tr>
            @endforeach
            <tr>
                <td colspan="{{ $fechas->count() + 1 }}" class="text-end"><strong>Total por {{ $cliente->nombre ?? 'Cliente Desconocido' }}</strong></td>
                <td><strong>{{ $productos->flatten(2)->sum('unidades') }}</strong></td>
            </tr>
        @endforeach
    </tbody>
    <tfoot>
        <tr>
            <th>Total</th>
            @foreach ($totalesPorFecha as $total)
                <th>{{ $total }}</th>
            @endforeach
            <th>{{ $totalGeneral }}</th>
        </tr>
    </tfoot>
</table>
@endsection
