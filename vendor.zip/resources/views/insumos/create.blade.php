@extends('layouts.app')

@section('content')
<div class="container">
    <h1 class="my-4">Crear Nuevo Insumo</h1>
    <form action="{{ route('insumos.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="proveedor_id">Proveedor:</label>
            <select id="proveedor_id" name="proveedor_id" class="form-control" required>
                <option value="">Selecciona un proveedor</option>
                @foreach($proveedores as $proveedor)
                    <option value="{{ $proveedor->id }}">{{ $proveedor->nombre }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="sku_padre">SKU Padre:</label>
            <input type="text" id="sku_padre" name="sku_padre" class="form-control" value="{{ old('sku_padre') }}" required>
        </div>
        <div class="form-group">
            <label for="sku_jerk">SKU Jerk:</label>
            <input type="text" id="sku_jerk" name="sku_jerk" class="form-control" value="{{ old('sku_jerk') }}" required>
        </div>
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" class="form-control" value="{{ old('nombre') }}" required>
        </div>
        <div class="form-group">
            <label for="unidad_de_medida">Unidad de Medida:</label>
            <select id="unidad_de_medida" name="unidad_de_medida" class="form-control" required>
                <option value="metros">Metros</option>
                <option value="unidades">Unidades</option>
                <option value="centimetros">Centímetros</option>
                <option value="Kg">Kg</option>
                <option value="Lt">Lt</option>
            </select>
        </div>
        <div class="form-group">
            <label for="precio_unitario">Precio Unitario:</label>
            <input type="number" id="precio_unitario" name="precio_unitario" class="form-control" step="0.01" value="{{ old('precio_unitario') }}" required>
        </div>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
</div>
@endsection
