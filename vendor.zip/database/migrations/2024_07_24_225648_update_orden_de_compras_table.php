<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('orden_de_compras', function (Blueprint $table) {
            $table->string('rut')->nullable();
            $table->string('nombre_cliente_final')->nullable();
        });
    }

    public function down()
    {
        Schema::table('orden_de_compras', function (Blueprint $table) {
            $table->string('rut')->nullable(false)->change();
            $table->string('nombre_cliente_final')->nullable(false)->change();
        });
    }
};