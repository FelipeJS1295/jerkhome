<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsToOrdenDeComprasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('orden_de_compras', function (Blueprint $table) {
            $table->string('rut')->nullable();
            $table->string('nombre_cliente_final')->nullable();
            $table->enum('estado_orden', ['nuevo', 'en proceso', 'terminado', 'despachado', 'devolucion'])->default('nuevo');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('orden_de_compras', function (Blueprint $table) {
            $table->dropColumn('rut');
            $table->dropColumn('nombre_cliente_final');
            $table->dropColumn('estado_orden');
        });
    }
}