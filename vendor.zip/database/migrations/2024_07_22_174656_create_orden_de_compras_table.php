<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdenDeComprasTable extends Migration
{
    public function up()
    {
        Schema::create('orden_de_compras', function (Blueprint $table) {
            $table->id();
            $table->date('fecha');
            $table->string('orden_de_compra');
            $table->foreignId('cliente_id')->constrained('clientes')->onDelete('cascade');
            $table->string('producto_id');
            $table->decimal('monto', 10, 2);
            $table->date('fecha_envio');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('orden_de_compras');
    }
}