

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Proveedores</h1>
        <a href="<?php echo e(route('proveedores.create')); ?>" class="btn btn-primary">Nuevo Proveedor</a>

        <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success mt-2">
                <?php echo e($message); ?>

            </div>
        <?php endif; ?>

        <table class="table mt-2">
            <thead>
                <tr>
                    <th>RUT</th>
                    <th>Nombre</th>
                    <th>Contacto</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($proveedor->rut); ?></td>
                        <td><?php echo e($proveedor->nombre); ?></td>
                        <td><?php echo e($proveedor->contacto); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u137169258/domains/quantiumcoders.cl/public_html/fabrica-muebles/resources/views/proveedores/index.blade.php ENDPATH**/ ?>