

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="my-4">Crear Nuevo Insumo</h1>
    <form action="<?php echo e(route('insumos.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="proveedor_id">Proveedor:</label>
            <select id="proveedor_id" name="proveedor_id" class="form-control" required>
                <option value="">Selecciona un proveedor</option>
                <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($proveedor->id); ?>"><?php echo e($proveedor->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="sku_padre">SKU Padre:</label>
            <input type="text" id="sku_padre" name="sku_padre" class="form-control" value="<?php echo e(old('sku_padre')); ?>" required>
        </div>
        <div class="form-group">
            <label for="sku_jerk">SKU Jerk:</label>
            <input type="text" id="sku_jerk" name="sku_jerk" class="form-control" value="<?php echo e(old('sku_jerk')); ?>" required>
        </div>
        <div class="form-group">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" class="form-control" value="<?php echo e(old('nombre')); ?>" required>
        </div>
        <div class="form-group">
            <label for="unidad_de_medida">Unidad de Medida:</label>
            <select id="unidad_de_medida" name="unidad_de_medida" class="form-control" required>
                <option value="metros">Metros</option>
                <option value="unidades">Unidades</option>
                <option value="centimetros">Centímetros</option>
                <option value="Kg">Kg</option>
                <option value="Lt">Lt</option>
            </select>
        </div>
        <div class="form-group">
            <label for="precio_unitario">Precio Unitario:</label>
            <input type="number" id="precio_unitario" name="precio_unitario" class="form-control" step="0.01" value="<?php echo e(old('precio_unitario')); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u137169258/domains/quantiumcoders.cl/public_html/fabrica-muebles/resources/views/insumos/create.blade.php ENDPATH**/ ?>