

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Clientes</h1>
    <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-primary mb-3">Crear Nuevo Cliente</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>RUT</th>
                <th>Nombre</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($cliente->id); ?></td>
                    <td><?php echo e($cliente->rut); ?></td>
                    <td><?php echo e($cliente->nombre); ?></td>
                    <td>
                        <a href="<?php echo e(route('clientes.edit', $cliente->id)); ?>" class="btn btn-warning">Editar</a>
                        <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u137169258/domains/quantiumcoders.cl/public_html/fabrica-muebles/resources/views/clientes/index.blade.php ENDPATH**/ ?>