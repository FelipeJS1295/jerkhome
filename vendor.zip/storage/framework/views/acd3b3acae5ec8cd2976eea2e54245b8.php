<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">JERK HOME</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="ordenesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Órdenes de Compra
                </a>
                <div class="dropdown-menu" aria-labelledby="ordenesDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('ordenes-de-compra.index')); ?>">Listado de Órdenes</a>
                    <a class="dropdown-item" href="<?php echo e(route('excel.import.form')); ?>">Carga de OC</a>
                    <a class="dropdown-item" href="<?php echo e(route('ordenes-de-compra.maestra')); ?>">Maestra</a>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="ordenesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Mantenedores
                </a>
                <div class="dropdown-menu" aria-labelledby="ordenesDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('clientes.index')); ?>">Clientes</a>
                    <a class="dropdown-item" href="<?php echo e(route('productos.index')); ?>">Productos</a>
                </div>
            </li>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\jerkhome\fabrica-muebles\resources\views/layouts/header.blade.php ENDPATH**/ ?>