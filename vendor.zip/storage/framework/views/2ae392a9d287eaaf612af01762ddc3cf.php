

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Productos</h1>
    <a href="<?php echo e(route('productos.create')); ?>" class="btn btn-primary">Agregar Producto</a>
    <table class="table mt-4">
        <thead>
            <tr>
                <th>SKU</th>
                <th>Nombre</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($producto->sku); ?></td>
                <td><?php echo e($producto->nombre); ?></td>
                <td>
                    <a href="<?php echo e(route('productos.edit', $producto->id)); ?>" class="btn btn-warning">Editar</a>
                    <form action="<?php echo e(route('productos.destroy', $producto->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u137169258/domains/quantiumcoders.cl/public_html/fabrica-muebles/resources/views/productos/index.blade.php ENDPATH**/ ?>