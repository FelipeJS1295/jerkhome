

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="my-4">Listado de Insumos</h1>
    <a href="<?php echo e(route('insumos.create')); ?>" class="btn btn-primary mb-3">Agregar Nuevo Insumo</a>
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Proveedor</th>
                    <th>SKU Padre</th>
                    <th>SKU Jerk</th>
                    <th>Nombre</th>
                    <th>Unidad de Medida</th>
                    <th>Precio Unitario</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insumo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($insumo->id); ?></td>
                        <td><?php echo e($insumo->proveedor->nombre); ?></td>
                        <td><?php echo e($insumo->sku_padre); ?></td>
                        <td><?php echo e($insumo->sku_jerk); ?></td>
                        <td><?php echo e($insumo->nombre); ?></td>
                        <td><?php echo e($insumo->unidad_de_medida); ?></td>
                        <td>$<?php echo e(number_format($insumo->precio_unitario, 2)); ?></td>
                        <td>
                            <a href="<?php echo e(route('insumos.edit', $insumo->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                            <form action="<?php echo e(route('insumos.destroy', $insumo->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u137169258/domains/quantiumcoders.cl/public_html/fabrica-muebles/resources/views/insumos/index.blade.php ENDPATH**/ ?>