

<?php $__env->startSection('content'); ?>
<h1>Maestra de Órdenes de Compra</h1>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Producto</th>
            <?php $__currentLoopData = $fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th><?php echo e($fecha); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $clientesConOrdenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clienteId => $productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $cliente = App\Models\Cliente::find($clienteId);
            ?>
            <tr>
                <td colspan="<?php echo e($fechas->count() + 2); ?>" class="bg-light">
                    <?php echo e($cliente->nombre ?? 'Cliente Desconocido'); ?>

                </td>
            </tr>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productoId => $ordenesPorFecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $producto = App\Models\Producto::find($productoId);
                ?>
                <tr>
                    <td><?php echo e($producto->nombre ?? 'Producto Desconocido'); ?></td>
                    <?php $__currentLoopData = $fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($ordenesPorFecha->get($fecha, collect())->sum('unidades')); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($ordenesPorFecha->flatten()->sum('unidades')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="<?php echo e($fechas->count() + 1); ?>" class="text-end"><strong>Total por <?php echo e($cliente->nombre ?? 'Cliente Desconocido'); ?></strong></td>
                <td><strong><?php echo e($productos->flatten(2)->sum('unidades')); ?></strong></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <th>Total</th>
            <?php $__currentLoopData = $totalesPorFecha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th><?php echo e($total); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th><?php echo e($totalGeneral); ?></th>
        </tr>
    </tfoot>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u137169258/domains/quantiumcoders.cl/public_html/fabrica-muebles/resources/views/ordenes_de_compra/maestra.blade.php ENDPATH**/ ?>