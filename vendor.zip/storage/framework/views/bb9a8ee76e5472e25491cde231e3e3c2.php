

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1>Órdenes de Compra</h1>
    <a href="<?php echo e(route('ordenes-de-compra.create')); ?>" class="btn btn-primary mb-3">Crear Nueva Orden de Compra</a>

    <!-- Mostrar errores -->
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <!-- Mostrar mensajes de éxito -->
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <!-- Formulario de filtros -->
    <form method="GET" action="<?php echo e(route('ordenes-de-compra.index')); ?>" class="mb-4">
        <div class="form-row align-items-end">
            <div class="col-md-3">
                <label for="orden_de_compra">Orden de Compra</label>
                <input type="text" name="orden_de_compra" id="orden_de_compra" class="form-control" placeholder="Orden de Compra" value="<?php echo e(request('orden_de_compra')); ?>">
            </div>
            <div class="col-md-3">
                <label for="cliente">Cliente</label>
                <input type="text" name="cliente" id="cliente" class="form-control" placeholder="Cliente" value="<?php echo e(request('cliente')); ?>">
            </div>
            <div class="col-md-3">
                <label for="fecha">Fecha</label>
                <input type="date" name="fecha" id="fecha" class="form-control" placeholder="Fecha" value="<?php echo e(request('fecha')); ?>">
            </div>
            <div class="col-md-3">
                <label for="estado">Estado</label>
                <select name="estado" id="estado" class="form-control">
                    <option value="">Estado</option>
                    <option value="nuevo" <?php echo e(request('estado') == 'nuevo' ? 'selected' : ''); ?>>Nuevo</option>
                    <option value="en proceso" <?php echo e(request('estado') == 'en proceso' ? 'selected' : ''); ?>>En proceso</option>
                    <option value="terminado" <?php echo e(request('estado') == 'terminado' ? 'selected' : ''); ?>>Terminado</option>
                    <option value="despachado" <?php echo e(request('estado') == 'despachado' ? 'selected' : ''); ?>>Despachado</option>
                    <option value="devolucion" <?php echo e(request('estado') == 'devolucion' ? 'selected' : ''); ?>>Devolución</option>
                </select>
            </div>
        </div>
        <div class="form-row mt-2">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary">Filtrar</button>
                <a href="<?php echo e(route('ordenes-de-compra.index')); ?>" class="btn btn-secondary">Limpiar</a>
            </div>
        </div>
    </form>

    <!-- Formulario para actualizar el estado de órdenes seleccionadas -->
    <div class="form-group">
        <label for="nuevo_estado">Cambiar estado a:</label>
        <div class="input-group">
            <select name="nuevo_estado" id="nuevo_estado" class="form-control">
                <option value="nuevo">Nuevo</option>
                <option value="en proceso">En proceso</option>
                <option value="terminado">Terminado</option>
                <option value="despachado">Despachado</option>
                <option value="devolucion">Devolución</option>
            </select>
            <div class="input-group-append">
                <button type="button" class="btn btn-primary" id="cambiarEstadoBtn">Actualizar Estado</button>
            </div>
        </div>
    </div>

    <!-- Lista de órdenes en tabla -->
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th><input type="checkbox" id="selectAll"></th>
                    <th>Orden de Compra</th>
                    
                    <th>Fecha de Compra</th>
                    <th>Cliente</th>
                    <th>Producto</th>
                    <th>Monto</th>
                    <th>Fecha de Envío</th>
                    <th>Unidades</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ordenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><input type="checkbox" class="ordenCheckbox" value="<?php echo e($orden->id); ?>"></td>
                    <td><?php echo e($orden->orden_de_compra); ?></td>
                    
                    <td><?php echo e(\Carbon\Carbon::parse($orden->fecha)->format('d-m-Y')); ?></td>
                    <td><?php echo e($orden->cliente->nombre); ?></td>
                    <td><?php echo e($orden->producto->nombre); ?></td>
                    <td>$<?php echo e(number_format($orden->monto, 2)); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($orden->fecha_envio)->format('d-m-Y')); ?></td>
                    <td><?php echo e($orden->unidades); ?></td>
                    <td><?php echo e($orden->estado_orden); ?></td>
                    <td>
                        <a href="<?php echo e(route('ordenes-de-compra.edit', $orden->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                        <form action="<?php echo e(route('ordenes-de-compra.destroy', $orden->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Script para manejar la actualización de estado -->
<script>
    document.getElementById('selectAll').addEventListener('click', function() {
        let checkboxes = document.querySelectorAll('.ordenCheckbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
    });

    document.getElementById('cambiarEstadoBtn').addEventListener('click', function() {
        let seleccionados = [];
        document.querySelectorAll('.ordenCheckbox:checked').forEach((checkbox) => {
            seleccionados.push(checkbox.value);
        });

        if (seleccionados.length > 0) {
            let nuevoEstado = document.getElementById('nuevo_estado').value;

            fetch('<?php echo e(route("ordenes-de-compra.updateEstadoMultiple")); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: JSON.stringify({
                        ordenes: seleccionados,
                        nuevo_estado: nuevoEstado
                    })
                }).then(response => response.json())
                .then(data => {
                    if (data.success) {
                        location.reload();
                    } else {
                        alert('Error al actualizar el estado');
                    }
                });
        } else {
            alert('Por favor, selecciona al menos una orden');
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jerkhome\fabrica-muebles\resources\views/ordenes_de_compra/index.blade.php ENDPATH**/ ?>