

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Previsualización de Órdenes de Compra</h1>
    <form action="<?php echo e(route('excel.upload')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Orden de Compra</th>
                    <th>Fecha</th>
                    <th>Cliente</th>
                    <th>Producto</th>
                    <th>Monto</th>
                    <th>Fecha de Envío</th>
                    <th>Rut boleta</th>
                    <th>nombre_cliente_final</th>
                    <th>Estado</th>
                    <th>Acciones</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e($row['es_repetida'] ? 'table-warning' : ''); ?>">
                        <td><?php echo e($row['orden_de_compra']); ?></td>
                        <td><?php echo e($row['fecha']); ?></td>
                        <td><?php echo e($row['cliente']); ?></td>
                        <td><?php echo e($row['producto']); ?></td>
                        <td><?php echo e($row['monto']); ?></td>
                        <td><?php echo e($row['fecha_envio']); ?></td>
                        <td><?php echo e($row['rut']); ?></td>
                        <td><?php echo e($row['nombre_cliente_final']); ?></td>
                        <td><?php echo e($row['estado_orden']); ?></td>
                        <td>
                            <?php if($row['es_repetida']): ?>
                                <button type="button" class="btn btn-danger btn-sm eliminar-orden" data-index="<?php echo e($index); ?>">Eliminar</button>
                            <?php else: ?>
                                <input type="checkbox" name="data[<?php echo e($index); ?>][incluir]" checked>
                            <?php endif; ?>
                            <input type="hidden" name="data[<?php echo e($index); ?>][orden_de_compra]" value="<?php echo e($row['orden_de_compra']); ?>">
                            <input type="hidden" name="data[<?php echo e($index); ?>][fecha]" value="<?php echo e($row['fecha']); ?>">
                            <input type="hidden" name="data[<?php echo e($index); ?>][cliente]" value="<?php echo e($row['cliente']); ?>">
                            <input type="hidden" name="data[<?php echo e($index); ?>][producto]" value="<?php echo e($row['producto']); ?>">
                            <input type="hidden" name="data[<?php echo e($index); ?>][monto]" value="<?php echo e($row['monto']); ?>">
                            <input type="hidden" name="data[<?php echo e($index); ?>][fecha_envio]" value="<?php echo e($row['fecha_envio']); ?>">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button type="submit" class="btn btn-primary">Guardar Órdenes</button>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.eliminar-orden').forEach(function(button) {
            button.addEventListener('click', function() {
                let rowIndex = this.dataset.index;
                let row = this.closest('tr');
                row.remove();
                // Marcar la orden para no ser incluida en la carga
                document.querySelector(`input[name="data[${rowIndex}][incluir]"]`).checked = false;
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u137169258/domains/quantiumcoders.cl/public_html/fabrica-muebles/resources/views/ordenes_de_compra/preview.blade.php ENDPATH**/ ?>