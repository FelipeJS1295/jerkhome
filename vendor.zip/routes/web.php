<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\OrdenDeCompraController;
use App\Http\Controllers\ExcelImportController;
use App\Http\Controllers\ProveedorController;
use App\Http\Controllers\InsumoController;
use App\Http\Controllers\CompraController;

Route::get('/', function () {
    return view('welcome');
});

Route::resource('clientes', ClienteController::class);
Route::resource('productos', ProductoController::class);
Route::resource('ordenes-de-compra', OrdenDeCompraController::class);

// Ruta para la carga masiva de órdenes de compra
// Route::post('ordenes-de-compra/carga-masiva', [OrdenDeCompraController::class, 'cargaMasiva'])->name('ordenes-de-compra.cargaMasiva');

// Rutas para la importación de Excel
Route::get('import-excel', [ExcelImportController::class, 'showImportForm'])->name('excel.import.form');
Route::post('import-excel', [ExcelImportController::class, 'import'])->name('excel.import');
Route::post('upload-excel', [ExcelImportController::class, 'store'])->name('excel.upload');
Route::post('ordenes-de-compra/update-estado-multiple', [OrdenDeCompraController::class, 'updateEstadoMultiple'])->name('ordenes-de-compra.updateEstadoMultiple');
Route::get('maestra', [OrdenDeCompraController::class, 'maestra'])->name('ordenes-de-compra.maestra');
Route::resource('proveedores', ProveedorController::class);
Route::resource('insumos', InsumoController::class);
Route::resource('compras', CompraController::class);